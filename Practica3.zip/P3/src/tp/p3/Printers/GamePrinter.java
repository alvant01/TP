package tp.p3.Printers;


public interface GamePrinter {
	
	public void printGame();
	
	public void encodeGame();
}
