package tp.p3.List;

public class PasiveGameObject extends GameObject {

	public PasiveGameObject() {
		// TODO Auto-generated constructor stub
	}

	public PasiveGameObject(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

}
